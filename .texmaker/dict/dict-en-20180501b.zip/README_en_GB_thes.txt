en_GB is using the WordNet thesaurus from the en_US directory.
